<link href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css" rel="stylesheet">
       <link href="https://cdn.datatables.net/buttons/1.5.2/css/buttons.dataTables.min.css" rel="stylesheet">
       <link href="<?php echo URL; ?>public/css/select2.min.css" rel="stylesheet">
<script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.5.2/js/dataTables.buttons.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.36/pdfmake.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.36/vfs_fonts.js"></script>
<script src="https://cdn.datatables.net/buttons/1.5.2/js/buttons.html5.min.js"></script>
<script src="<?php echo URL; ?>public/js/select2.min.js"></script>
<style>
   table.tdesign tr.odd { background-color:  whitesmoke; }
   table.tdesign tr.even { background-color: white;  }	
   table.tdesign th {
   background: #d9edf7;
   color: #000;
   padding: 2px;
   border: 1px solid #ccc;
   }
   table.tdesign td {
   padding: 1px;
   border: 1px solid #000;
   background: transparent;
   height:15px;
   white-space: nowrap; 
   }
</style>
<script>
$(document).ready(function() {
$("#today").click(function(){
//alert("success");
var from = "<?php echo date('Y-m-d'); ?>";
var to = "<?php echo date('Y-m-d'); ?>";
var divobj1 = document.getElementById('from');
divobj1.value = from;
var divobj2 = document.getElementById('to');
divobj2.value = to;
});
$("#yesterday").click(function(){
//alert("success");
var to = "<?php echo date('Y-m-d', strtotime('-1 day')); ?>";
var from = "<?php echo date('Y-m-d', strtotime('-1 day')); ?>";
var divobj1 = document.getElementById('from');
divobj1.value = from;
var divobj2 = document.getElementById('to');
divobj2.value = to;
});
$("#week").click(function(){
//alert("success");
var to = "<?php echo date('Y-m-d'); ?>";
var from = "<?php echo date('Y-m-d', strtotime('-7 day')); ?>";
var divobj1 = document.getElementById('from');
divobj1.value = from;
var divobj2 = document.getElementById('to');
divobj2.value = to;
});
$("#month").click(function(){
//alert("success");
var to = "<?php echo date('Y-m-d'); ?>";
var from = "<?php echo date('Y-m-d', strtotime('-30 day')); ?>";
var divobj1 = document.getElementById('from');
divobj1.value = from;
var divobj2 = document.getElementById('to');
divobj2.value = to;
});
//$("#lifetime").click(function(){
////alert("success");
//var to = "<?php echo date('Y-m-d'); ?>";
//var from = "<?php echo date('Y-m-d', strtotime('-90 day')); ?>";
//var divobj1 = document.getElementById('from');
//divobj1.value = from;
//var divobj2 = document.getElementById('to');
//divobj2.value = to;
//});
});
</script>
<div class="container-fluid" style="padding: 0px; margin-bottom: 20px;">
<div class="tab-content">
   <div id="home" class="tab-pane fade in active">
      <div class="white_div" style="">
         <div class="title_div">
            <span class="title_pra" style="font-size:18px;"><strong>Vendor challan Details</strong></span>
               <input type="button" id="btnAdd"  class="btn btn-info pull-right" class="btn btn-info pull-right" style="width:10%; font-size:10px;" onclick="addDieselIssue()" value="Add Issue"> 
                 </div>
         <br>
         <center> <input type="text" id="searchTxt" placeholder="Search"></center>
         <br>
          <center>
               <div class="col-xs-12 col-md-6 col-sm-6 col-lg-6 form-group">
                               <label class="control-label col-xs-12" for="date"> Vendor:</label>
                               <div class="col-xs-12 col-md-6 col-sm-6 col-lg-6">
                                  <select class="form-control" name="vendorcode" id="vendorcode" onchange="" style="width:100%;"> 
                                      <option value="0">Select Vendor</option>
                                  </select>
                               </div>
                  </div>   
                 <div class="col-xs-12 col-md-6 col-sm-6 col-lg-6 form-group">
                               <label class="control-label col-xs-12" for=" Date">  Date:</label>
                               <div class="col-xs-12 col-md-6 col-sm-6 col-lg-6">
                               <input type="date" data-validation-error-msg="" class="form-control" name="date" id="date" placeholder="Enter Date" value="">
                                 </div>
                 </div>
<!--
       <button type="button" class="btn btn-primary" name="today" id="today">Today</button>
       <button type="button" class="btn btn-primary" name="yesterday" id="yesterday">Yesterday</button>
       <button type="button" class="btn btn-primary" name="week" id="week">Week</button>
       <button type="button" class="btn btn-primary" name="month" id="month">Month</button>
-->
       
     
  </center>
         <div class="table-responsive" id="table" hiden>
            
            <table id="example" class="cell-border tdesign" width="100%" cellspacing="0">
               <thead><tr>
                                 <th>Sr No</th>
                             
                                 <th>Date</th>
                                 <th>Vehicle Number</th>
                                 <th>Diesel Issue</th>
                                 <th>Diesel Rate</th>
                                 <th>Diesel Amount

                                  <th></th>
                                    <th></th>
                                
   
                               </tr></thead>
                     </table>	
                     </div>   