<script>
$(document).ready(function() {
$("#today").click(function(){
//alert("success");
var from = "<?php echo date('Y-m-d'); ?>";
var to = "<?php echo date('Y-m-d'); ?>";
var divobj1 = document.getElementById('from');
divobj1.value = from;
var divobj2 = document.getElementById('to');
divobj2.value = to;
});
$("#yesterday").click(function(){
//alert("success");
var to = "<?php echo date('Y-m-d'); ?>";
var from = "<?php echo date('Y-m-d', strtotime('-1 day')); ?>";
var divobj1 = document.getElementById('from');
divobj1.value = from;
var divobj2 = document.getElementById('to');
divobj2.value = to;
});
$("#week").click(function(){
//alert("success");
var to = "<?php echo date('Y-m-d'); ?>";
var from = "<?php echo date('Y-m-d', strtotime('-7 day')); ?>";
var divobj1 = document.getElementById('from');
divobj1.value = from;
var divobj2 = document.getElementById('to');
divobj2.value = to;
});
$("#month").click(function(){
//alert("success");
var to = "<?php echo date('Y-m-d'); ?>";
var from = "<?php echo date('Y-m-d', strtotime('-30 day')); ?>";
var divobj1 = document.getElementById('from');
divobj1.value = from;
var divobj2 = document.getElementById('to');
divobj2.value = to;
});
$("#lifetime").click(function(){
//alert("success");
var to = "<?php echo date('Y-m-d'); ?>";
var from = "<?php echo date('Y-m-d', strtotime('-90 day')); ?>";
var divobj1 = document.getElementById('from');
divobj1.value = from;
var divobj2 = document.getElementById('to');
divobj2.value = to;
});
});
</script>
<div class="container-fluid" style="padding: 0px; margin-bottom: 20px;">
  <div class="tab-content">
     <div id="home" class="tab-pane fade in active">
        <div class="white_div" style="">
           <div class="title_div">
             <span class="title_pra" style="font-size:18px;"><strong>Attendance</strong></span>
            </div>
             <center>
                       
                        <button type="button" class="btn btn-primary" name="today" id="today" >Today</button>
                        <button type="button" class="btn btn-primary" name="yesterday" id="yesterday" >Yesterday</button>
                        <button type="button" class="btn btn-primary" name="month" id="month">Month</button>
                      
                    </center>

<span class="" style="top:0%;font-size:25px;color:white;margin-left:20px;">Attendance</span>
</div>

<!--
<div class="header sub header deep-purple-700" style="height:50px" id="subheader">

<div class="buttons-group full small">
<button class="border-purple radius-left" style="background-color: #98fb98;" onclick="showData('today')">
    <span id="today" style="font-size:11px">Today <span id="todaytxt" style="font-size:11px"></span></span>
</button>
<button class="border-purple" style="background-color: #FFE766;" onclick="showData('yesterday')">
    <span id="yesterday" style="font-size:11px">Yesterday <span id="yesterdaytxt" style="font-size:11px"></span></span>
</button>

<button class="border-purple radius-right" style="background-color: #d798fb;" onclick="showData('month')">
    <span id="month" style="font-size:11px">Month <span id="monthtxt" style="font-size:11px"></span>
</button>
</div>
</div>
-->
</div>
<!-- <div style="background-color:#fff;height:47.9px;border-bottom: 1px black solid;padding:1px;">
<span class="pull-left" style="font-size:28px;color:green;margin-top:8px;margin-left:5px;text-shadow: 1px 1px 1px #ccc;" id="returnHome" onclick="window.location.href='dashboard.html'"><i class="fa fa-home"></i></span>
<strong><span class="pull-left" style="text-align:center;font-size:22px;color:midnightblue;margin-top:8px;margin-left:5px;font-weight:bold;" id="SectionTitle">Attendance</span> </strong>   

<span class="pull-right" style="font-size:28px;color:green;margin-top:8px;margin-right:5px;text-shadow: 1px 1px 1px #ccc;" id="returnBack" onclick="onBackKeyDown()"><i class="fa fa-arrow-left"></i></span>

<span class="pull-right" id="progress" style="margin-top:5px;font-size:18px;"><img src="img/progress-gif.gif" height="34px" /></span>        
</div> -->
<div class="table-responsive">  
	                            <div class="table-responsive">
								
	                             
		<table id="example" class="cell-border tdesign" width="100%" cellspacing="0">
        										<thead><tr>
                                               <th>Employee</th>
                                                <th>Date</th>
                                                <th>Location</th>
                                                    </tr>
            </thead>
                                    </table>
    </div></div>
                 
<!--
<div id="employeeList" style="margin-top:110px;">
      
                </div>
-->
<div id="formId">
                <div class="container">
                        <div class="row" >
                        <div class="col-6 GeoDataColm">       
                        <p class="NameParagraph" style="font-size:11px;font-family:Roboto, sans-serif;padding-top:0px;padding-left:10px;">Month</p>
                        <input type="month" required placeholder=""
                        style="font-family:Roboto, sans-serif;font-size:12px;" id="from" class="form-control inputForm"/>
                        <div id="alertMsgTxt" style="color:red;"></div>     
                        </div>
                        
                        
                        <div class="col-6 GeoDataColm" style="margin-top:30px;">
                        <input class="btn btn-info" type="button" style="background-color:black;font-family:Roboto, sans-serif;" value="SUBMIT"
                        id="submitBtn" onclick="SubmitBtn()">
                        </div>
                        </div>
                        
                        </div> 
        </div>     
                
<!--
<div class="container">
        <div class="showResInput" style="padding-top:0px;" >
         <form action="" class="showResInput" autocomplete="off" class="form-horizontal" method="post" accept-charset="utf-8"> 
        <div class="input-group">
        <input name="searchTxt" value="" class="form-control" type="text" id="searchTxt">
        <span class="input-group-btn">
        <button class="btn btn-default btnsearch" type="submit" id="addressSearch">
        <i id="searchiconcolr" class="fa fa-search"></i>
        </button>
        </span>
        </div>
        </div> 
        </div>          
-->

<!--<a href="#" onclick="UpdateInfo();" >Refresh</a>-->

<!--
<div id="todayAttendanceId">
<ul class="accordion">
    
    <li>
    <a class="toggle" href="javascript:void(0);"><div id="row"><div id="left"><div class="circleVehicle" style="background-color: #98fb98">PRESENT TODAY</div></div><div id="middle"></div><div id="right"><div class="circle" style="background-color: #FFE766;"><span id="employee" style="color:black;font-weight: bold;"></span></div></div></div></a><ul class="inner" style="display: none;" id="employeelist"></ul>
    </li>
    </ul>
    </div>

<div id="yesterdayAttendanceId">
<ul class="accordion">

        <li>
        <a class="toggle" href="javascript:void(0);"><div id="row"><div id="left"><div class="circleVehicle" style="background-color: #98fb98">PRESENT YESTERDAY</div></div><div id="middle"></div><div id="right"><div class="circle" style="background-color: #FFE766;"><span id="employeey"  style="color:black;font-weight: bold;"></span></div></div></div></a><ul class="inner" style="display: none;" id="employeelisty"></ul>
        </li>
        </ul>
</div>
<div id="monthlyAttendanceId">
  
<ul class="accordion" id="allTabs">
 </ul>
 </div>
</div>
-->
<script>
var employeeArr=[];
var id=0, EM_NAME=0;
var t, d, year, month, day,dat,date;
//var employeeList = document.getElementById("employeeList");
//var containScan = document.getElementById("containScan");
//containScan.style.display = "none";
//var userType = localStorage['userType'];
//var admin_id = localStorage['admin_id'];
//var traccarID =localStorage['traccarID'];
//var traccar_email=localStorage['traccar_email'];
//var pass= localStorage['pass'];
//var button = document.getElementById("submitbtn");
//var src=document.getElementById("src");
//var vehicleDetails = document.getElementById("vehicleDetails");                                                  
//var serverUrl = localStorage['serverUrl'];                                   
//var parent_id = localStorage['parent_id'];
//var parent_traccarID=localStorage['parent_traccarID'];
//var userID = localStorage['employeeID'];
//var USER = localStorage["username"];
//var username1 = document.getElementById("username");
//        username1.innerHTML=USER;
//var todayAttendanceId = document.getElementById("todayAttendanceId");
//var yesterdayAttendanceId  = document.getElementById("yesterdayAttendanceId");
//var monthlyAttendanceId = document.getElementById("monthlyAttendanceId"); 
//var formId = document.getElementById("formId");
//var subheader = document.getElementById("subheader");
formId.style.display = "none";
//todayAttendanceId.style.display = "none";  
//yesterdayAttendanceId.style.display="none";
//monthlyAttendanceId.style.display="none";

$("#today").click(function(){
//alert("success");
var from = "<?php echo date('Y-m-d'); ?>";
var to = "<?php echo date('Y-m-d'); ?>";
    createTable();
});
$("#yesterday").click(function(){
//alert("success");
var to = "<?php echo date('Y-m-d'); ?>";
var from = "<?php echo date('Y-m-d', strtotime('-1 day')); ?>";

        createTable();
});
function showData(id){
    if(id == "today"){
//        todayAttendanceId.style.display = "block";  
//yesterdayAttendanceId.style.display="none";
//monthlyAttendanceId.style.display="none";
formId.style.display = "none";

    }
    if(id == "yesterday"){
//        todayAttendanceId.style.display = "none";  
//yesterdayAttendanceId.style.display="block";
//monthlyAttendanceId.style.display="none";
formId.style.display = "none";

    }
    if(id == "month"){
//todayAttendanceId.style.display = "none";  
//yesterdayAttendanceId.style.display="none";
//monthlyAttendanceId.style.display="block";
formId.style.display = "block";
    }

}

//
//function addEmployee(){
//    employeeList.style.display="none";
//    containScan.style.display="block";
//    subheader.style.display = "none";
//    dateFun();
//    employeeAttendance();
//    document.getElementById("icon").className = "icon ion-android-arrow-back visible";
//
//}
document.addEventListener("deviceready", onDeviceReady, false);
function onDeviceReady() {
//    getAllEmployees();
    createTable();
          showData('today');
          //  alert("called");
            // var watchID = navigator.geolocation.watchPosition(onSuccess, onError, { timeout: 30000 });
            ///// navigator.geolocation.getCurrentPosition(onSuccess, onError);
          }

// function backemployee(){
//   employeeList.style.display="block";
//     containScan.style.display="none";
// }

function dateFun(){
t = new Date().toLocaleTimeString();
d = new Date(); 
year=d.getFullYear();
month=d.getMonth()+1;
if(month.toString().length == 1){
month = "0"+month;
}
day=d.getDate();
if(day.toString().length == 1){
day = "0"+day;
}
                                                                                    
dat=year+"-"+month+"-"+day;
date=dat+" "+t;
document.getElementById("issuedate").innerHTML = date;
// date1 = month+"-"+year;

}
    
    function createTable(){
        
         var txt='';
    var tdEmployeeName="", tdDate="", tdLocation="";
   displayTable= [];
    var xhr = new XMLHttpRequest(), 
        method = 'GET',
        overrideMimeType = 'application/json',
        url = ''+serverUrl+'reports/getattendance?date'++; 
              // ADD THE URL OF THE FILE.
   
    xhr.onreadystatechange = function () {
        if (xhr.readyState === XMLHttpRequest.DONE && xhr.status === 200) {
                
            // PARSE JSON DATA.
            if(xhr.responseText){
   
              // alert(xhr.responseText);
               var data=JSON.parse(xhr.responseText);
               for(var i=0; i<data.length; i++){
                tdEmployeeName= '<tr style="height:20px;" role="row"><td>'+data[i]['employeename']+'</td>';
   	            tdDate = '<td>'+data[i]['date']+'</td>';
                tdLocation='<td>'+data[i]['location']+'</td>';
//          tdChesisNo='<td>'+data[i]['ChesisNo']+'</td>';
//          tdOwner='<td>'+partyArr[data[i]['OwnerType']]+'</td>';
//          tdFitness='<td  style="text-align:center;background-color:'+getDateDifferenceColor(data[i]['FitnessExpiryDate']) +';">'+fitness+'</td>';
//          tdInsurance='<td style="text-align:center;background-color:'+getDateDifferenceColor(data[i]['InsuranceExpiryDate']) +';">'+insurance+'</td>';
//          tdPermit='<td style="text-align:center;background-color:'+getDateDifferenceColor(data[i]['PermitExpiry']) +';">'+permit+'</td>';
//          tdRoadTax='<td style="text-align:center;background-color:'+getDateDifferenceColor(data[i]['RoadTaxExpiry']) +';">'+roadtax+'</td>';
//          tdPollution='<td style="text-align:center;background-color:'+getDateDifferenceColor(data[i]['PollutionExpiry']) +';">'+pollution+'</td>';
//          tdView='<td><a href="#a" onclick="javascript: view('+data[i]['id']+',1)"> VIEW</a></td>';
//          tdEdit='<td><a href="#a" onclick="javascript: view('+data[i]['id']+', 2)"> EDIT</button></td>';
//          tdDelete='<td id="deleteClick"><a href="#a" onclick="javascript:confirmDelete('+data[i]['id']+');" id="delete"> DELETE</a></td></tr>';
          txt = tdEmployeeName+tdDate+tdLocation;
          displayTable[i]= txt;
         
               }
             
          scrollPos = $("#example").scrollTop();
          otable.clear().draw();
          for(i = 0; i < displayTable.length; i++) {
          otable.row.add($(displayTable[i]));
            }
     otable.draw();
  
            }
        }
    };
   
    xhr.open(method, url, true);
    xhr.send();
    }
//function employeeAttendance(){
//
//$('#EmployeeName').val('').trigger('change');
//// $('#selfName').val('').trigger('change');
//$("#txtStatus").html("");
//$("#tripStatus").html("");
//id= 0;
//EM_NAME=0;
//}

// function onDeviceReady() {
//   alert("shjfbbdhf");
//var watchID = navigator.geolocation.watchPosition(onSuccess, onError, { maximumAge: 3000, timeout: 5000, enableHighAccuracy: true });
//}

//function onSuccess(position) {
//var element = document.getElementById('geolocation');
//if(userID==63){
//            //  $('#geolocation').show();
//            }
//            element.innerHTML = ''+position.coords.latitude  + ',' + position.coords.longitude  + '' ;
//            // 'Altitude: '           + position.coords.altitude              + '<br />' +
//            // 'Accuracy: '           + position.coords.accuracy              + '<br />' +
//            // 'Altitude Accuracy: '  + position.coords.altitudeAccuracy      + '<br />' +
//            // 'Heading: '            + position.coords.heading               + '<br />' +
//            // 'Speed: '              + position.coords.speed                 + '<br />' +
//            // 'Timestamp: '          + position.timestamp                    + '<br />';
//            // alert(position.coords.latitude+","+position.coords.longitude);
//        }

        
        // onError Callback receives a PositionError object
        //
//        function onError(error) {
//            var element = document.getElementById('geolocation');
//            element.innerHTML ='code: '    + error.code    + '\n' +'message: ' + error.message + '\n';
//
//        }

//
//function employeeBAR_code(){
//    cordova.plugins.barcodeScanner.scan(
//            function (result) {
//                var temp=result.text;
//                var dev=temp.split(":");
//                //alert(dev[0]);
//                if(dev[0]=="EM"){
//                id= dev[2];
//                EM_NAME=dev[1];
//            //       $("#ShowDrivers").hide();
//            //   $("#inout").hide();
//            //   $("#progress").show();
//
//            $('#EmployeeName').val(''+id+'').trigger('change');
//                
//                
//                }
//            }
//            ,  
//            function (error) {
//                alert("Scanning failed: " + error);
//            }
//            ,
//            {
//                preferBackCamera : true, // iOS and Android
//                showFlipCameraButton : true, // iOS and Android
//                showTorchButton : true, // iOS and Android
//                torchOn: false, // Android, launch with the torch switched on (if available)
//                saveHistory: true, // Android, save scan history (default false)
//                prompt : "Place a barcode inside the scan area", // Android
//                resultDisplayDuration: 500, // Android, display scanned text for X ms. 0 suppresses it entirely, default 1500
//                formats : "default", // default: all but PDF_417 and RSS_EXPANDED
//                orientation : "default", // Android only (portrait|landscape), default unset so it rotates with the device
//                disableAnimations : true, // iOS
//                disableSuccessBeep: false // iOS and Android
//            }
//            );
//};


function getAllEmployees(){
$.ajax({

url:""+serverUrl+"employee/getemployee",
type: "GET",
data: { 

},
dataType: "json",
success: function(returnedData) {
    employeeArr = [];
    localStorage['employeeLocalJSON'] = JSON.stringify(returnedData);

var eleName = document.getElementById('EmployeeName');
// var selfName =  document.getElementById("selfName");
for (var i = 0; i < returnedData.length; i++) {

    eleName.innerHTML = eleName.innerHTML +
    '<option value="' + returnedData[i]['id'] +'">' + returnedData[i]['name'] + '</option>'

    employeeArr[returnedData[i]['id']] = returnedData[i]['name'];
}

//alert(returnedData);
ALLEMPLOYEES= returnedData;
for(var k in returnedData) {
$("#allTabs").append('<li><a class="toggle" href="javascript:void(0);"><div id="row"><div id="left"><strong><div class="circleVehicle" style="background-color:palegreen" >' + returnedData[k]['name'] +'</div></strong></div><div id="middle"></div><div id="right"><div class="circle" style="background-color:#FFE766"><span id="attendanceNum'+k+'" style="font-weight: bold;font-size: 9px;"></span></div></div></div></a><ul class="inner" style="display: none;" id="employeelist'+k+'"></ul></li>');      
}

$('.toggle').click(function(e) {
e.preventDefault();
var $this = $(this);
if ($this.next().hasClass('show')) {
$this.next().removeClass('show');
$this.next().slideUp(350);
} 
else {

$this.parent().parent().find('li .inner').removeClass('show');
$this.parent().parent().find('li .inner').slideUp(350);
$this.next().toggleClass('show');
$this.next().slideToggle(350);
}
}); 
}
});
}
// function getAllEmployees(){
//             url = ""+serverUrl+"employee/getemployee";

        
//             var xhr = new XMLHttpRequest(), 
//                 method = 'GET',
//                 overrideMimeType = 'application/json';
//                 // alert(url)
//             //  $("#progress").show();
//             xhr.onreadystatechange = function () {
//             if (xhr.readyState === XMLHttpRequest.DONE && xhr.status === 200) {
//                 var data = JSON.parse(xhr.responseText);
//                 var eleName = document.getElementById('EmployeeName');
//                 // var selfName =  document.getElementById("selfName");
//                 for (var i = 0; i < data.length; i++) {
                
//                     eleName.innerHTML = eleName.innerHTML +
//                     '<option value="' + data[i]['id'] +'">' + data[i]['name'] + '</option>'
                
//                     employeeArr[data[i]['id']] = data[i]['name'];

                
//                 }
//                 //  $("#progress").hide();
//                 UpdateInfo()
//                 }
//             };
//             xhr.open(method, url, true);
//             xhr.send();
//         }


var oTable;
$(document).ready(function() {
    ////////////////////Navigation//////////////

//    erpNav();


////////////////End of Nav///////////////
if(localStorage['employeeLocalJSON'] != undefined){
var returnedData = JSON.parse(localStorage['employeeLocalJSON']);

var eleName = document.getElementById('EmployeeName');
// var selfName =  document.getElementById("selfName");
for (var i = 0; i < returnedData.length; i++) {

    eleName.innerHTML = eleName.innerHTML +
    '<option value="' + returnedData[i]['id'] +'">' + returnedData[i]['name'] + '</option>'

    employeeArr[returnedData[i]['id']] = returnedData[i]['name'];
}
}

if(localStorage['todayAttendanceLocalJSON'] != undefined){
var returnedData = JSON.parse(localStorage['todayAttendanceLocalJSON']);
$("#employeelist").empty();
for(var i=0; i<returnedData.length; i++){
                                                                                
$("#employee").html(returnedData.length);
//alert(returnedData[i]['employeeID'])
//alert(employeeArr.length);
var Employee = employeeArr[returnedData[i]['employeeID']];
//alert(Employee);
var str = Employee;
//str = str.replace(/\s/g,'');
var Time = "";
var Goelink = "";
            // if(Status=="load"){

Time = returnedData[i]['datetime'];                                                  
//  $("#issueltr").html(totalLtr+"Ltr");
allEmployees.push(Employee);
if(userID==63 || userID==54){

Goelink = '&nbsp;<a href="geo:'+returnedData[i]['location']+'?q='+returnedData[i]['location']+'('+Employee+')">Map</a>';
}
                                                                            
$("#employeelist").append("<li><ul class='innerbox'><li><strong>"+Employee+"</strong>"+Goelink+"<span class='"+GetTimeEvolved(Time,"null")+"'>"+CovertTimeHere(Time)+"</span><br /></li></ul></li>");

var unique = allEmployees.filter( onlyUnique ); 
//$("#mobileappjsonmtrips").html(unique.length);
}
$('#searchTxt').keyup();                                                                
}


                                                                
if(localStorage['yesterdayAttendanceLocalJSON'] != undefined){
var returnedData = JSON.parse(localStorage['yesterdayAttendanceLocalJSON']);
$("#employeelisty").empty();
for(var i=0; i<returnedData.length; i++){
                                                                                
$("#employeey").html(returnedData.length);
var Employee = employeeArr[returnedData[i]['employeeID']];
var str = Employee;
//alert(str);
//str = str.replace(/\s/g,'');
var Time = "";
            // if(Status=="load"){

Time = returnedData[i]['datetime'];                                                  
//  $("#issueltr").html(totalLtr+"Ltr");

                                                                            
$("#employeelisty").append("<li><ul class='innerbox'><li><strong>"+Employee+"</strong><span class='"+GetTimeEvolved(Time,"null")+"'>"+CovertTimeHere(Time)+"</span><br /></li></ul></li>");
                                                                            
}
}

        $("#EmployeeName").select2({
            
        });

        //         oTable =  $('#example').DataTable( {
        //    paging:false,
        //    "responsive": true,
        //  columnDefs: [
        //       { type: 'veh', targets: 0 }
        //   ]
        // } );
        
    } );

function changeEmployee(){
    dateFun();
    var employeeID=$("#EmployeeName").val();
    var EM_NAME1= employeeArr[employeeID];
    var dateTime = document.getElementById("issuedate").innerHTML;
    //  alert(dateTime)
    var location = document.getElementById('geolocation').innerHTML;
    $("#tripStatus").html("");

if(employeeID != ""){
    var xhr1 = new XMLHttpRequest(), 
                method = 'GET',
                overrideMimeType = 'application/json';
                url1=serverUrl+"employee/CheckEmployeeAttendance?employeeID="+employeeID+"";
                xhr1.onreadystatechange = function () {
            if (xhr1.readyState === XMLHttpRequest.DONE && xhr1.status === 200) {
                var data = JSON.parse(xhr1.responseText);
                // alert(data);
                if(data == ""){
            
    //alert(employeeID);
    if(userID != employeeID){
        $("#txtStatus").html("Thank You "+EM_NAME1+" for Your Attendance!<br />");

        var xhr = new XMLHttpRequest(), 
                method = 'GET',
                overrideMimeType = 'application/json';
                url=serverUrl+"employee/submit_employee_attendance?employeeID="+employeeID+"&datetime="+dateTime+"&location="+location+"&userID="+userID+"";
            // $("#progress").show();
            xhr.onreadystatechange = function () {
            if (xhr.readyState === XMLHttpRequest.DONE && xhr.status === 200) {
                // var data = JSON.parse(xhr.responseText);  
                $("#txtStatus").html(xhr.responseText);
                //  $("#progress").hide();
                $('#EmployeeName').val('').trigger('change');
                //attendanceTable();
                }
            };
            xhr.open(method, url, true);
            xhr.send();
    } else{
    
    if(userID == employeeID){
        $("#txtStatus").html("Use Self Button<br />");
    }else{
        $("#txtStatus").html("");
    }
    }
                }else{
                $("#txtStatus").html("Attendace Submitted<br />");
                attendanceTable(data);


                }
            }
                };
                xhr1.open(method, url1, true);
            xhr1.send();  
}  
    
}

//function selfChange(){
//    dateFun();
//    // alert(employeeID);
//    // alert(EM_NAME1);
//    var dateTime = document.getElementById("issuedate").innerHTML;
//    var location = document.getElementById('geolocation').innerHTML;
//    $("#tripStatus").html("");
//    if(userID != ""){
//    var xhr1 = new XMLHttpRequest(), 
//                method = 'GET',
//                overrideMimeType = 'application/json';
//                url1=serverUrl+"employee/CheckEmployeeAttendance?employeeID="+userID+"";
//                xhr1.onreadystatechange = function () {
//            if (xhr1.readyState === XMLHttpRequest.DONE && xhr1.status === 200) {
//                // alert(xhr1.responseText);
//                var data = JSON.parse(xhr1.responseText);
//                //alert(data)
//                if(data == ""){
//        $("#txtStatus").html("Thank You "+employeeArr[userID]+" for Your Attendance!<br />");
//        var xhr = new XMLHttpRequest(), 
//                method = 'GET',
//                overrideMimeType = 'application/json';
//                url=serverUrl+"employee/submit_employee_attendance?employeeID="+userID+"&datetime="+dateTime+"&location="+location+"&userID="+userID+"";
//            //  $("#progress").show();
//            xhr.onreadystatechange = function () {
//            if (xhr.readyState === XMLHttpRequest.DONE && xhr.status === 200) {
//                var data = JSON.parse(xhr.responseText);  
//                //   $("#progress").hide();
//                // attendanceTable();
//                $('#EmployeeName').val('').trigger('change');
//                }
//            };
//            xhr.open(method, url, true);
//            xhr.send();
//
//                }else{
//                    $("#txtStatus").html("Attendace Submitted<br />");
//                attendanceTable(data);
//
//
//                }
//                }
//                };
//                xhr1.open(method, url1, true);
//            xhr1.send();  
//}  
//    
//    }

// UpdateInfo();
function attendanceTable(data){
            //var 
        //  alert(data[0]['mployeeId'])
        
            var oTable1 = 			"<table border='1' width='95%' align='center' style='text-shadow:none;color:#000;margin-left:5px'>";
        
            oTable1 +=					"<tr style='background-color:#D3D3D3;'><td style='width:40%;padding-left:5px'>Employee Name</td><td style='width:60%;padding-left:5px'>"+employeeArr[data[0]['employeeID']]+"</td></tr>";
            
        //   if(vehicle_no!=null) {
            oTable1 +=	"<tr><td style='width:40%;padding-left:5px'>Date Time</td><td style='width:60%;padding-left:5px'>"+data[0]['datetime']+"</td></tr>";
        
            oTable1 +=	"</table>";
            // alert(oTable1);
            $("#tripStatus").html(oTable1);
            }

var allEmployees = [];

var myInterval;
var interval_delay = 500;
var is_interval_running = false;

myInterval = setInterval(function() { UpdateInfo(); }, 10000);


function UpdateInfo(){
                                                                

$.ajax({

url:serverUrl+"employee/getEmployeeAttendanceToday",
type: "GET",
data: { 

},
dataType: "json",
success: function(returnedData) {
// var totalLtr = 0;
localStorage['todayAttendanceLocalJSON'] = JSON.stringify(returnedData);
$("#employeelist").empty();
for(var i=0; i<returnedData.length; i++){
                                                                                
$("#employee").html(returnedData.length);
//alert(returnedData[i]['employeeID'])
var Employee = employeeArr[returnedData[i]['employeeID']];
//alert(Employee);
var str = Employee;
//str = str.replace(/\s/g,'');
var Time = "";
var Goelink = "";
            // if(Status=="load"){

Time = returnedData[i]['datetime'];                                                  
//  $("#issueltr").html(totalLtr+"Ltr");
allEmployees.push(Employee);
if(userID==63 || userID==54){

Goelink = '&nbsp;<a href="geo:'+returnedData[i]['location']+'?q='+returnedData[i]['location']+'('+Employee+')">Map</a>';
}
                                                                            
$("#employeelist").append("<li><ul class='innerbox'><li><strong>"+Employee+"</strong>"+Goelink+"<span class='"+GetTimeEvolved(Time,"null")+"'>"+CovertTimeHere(Time)+"</span><br /></li></ul></li>");

var unique = allEmployees.filter( onlyUnique ); 
//$("#mobileappjsonmtrips").html(unique.length);
}
$('#searchTxt').keyup();                                                                
}
});
                                                                
$.ajax({
                                                                    
url:serverUrl+"employee/getEmployeeAttendanceYesterday",
type: "GET",
data: { 
                                                                        
},
dataType: "json",
success: function(returnedData) {
localStorage['yesterdayAttendanceLocalJSON'] = JSON.stringify(returnedData);
$("#employeelisty").empty();
for(var i=0; i<returnedData.length; i++){
                                                                                
$("#employeey").html(returnedData.length);
var Employee = employeeArr[returnedData[i]['employeeID']];
var str = Employee;
//alert(str);
//str = str.replace(/\s/g,'');
var Time = "";
            // if(Status=="load"){

Time = returnedData[i]['datetime'];                                                  
//  $("#issueltr").html(totalLtr+"Ltr");

                                                                            
$("#employeelisty").append("<li><ul class='innerbox'><li><strong>"+Employee+"</strong><span class='"+GetTimeEvolved(Time,"null")+"'>"+CovertTimeHere(Time)+"</span><br /></li></ul></li>");
                                                                            

}
                                                                
}
});
                                                                
        } 

    function substr_replace(str, replace, start, length) {

if (start < 0) {
    start = start + str.length;
}
length = length !== undefined ? length : str.length;
if (length < 0) {
    length = length + str.length - start;
}
return str.slice(0, start) + replace.substr(0, length) + replace.slice(length) + str.slice(start + length);
}               
        function onlyUnique(value, index, self) { 
return self.indexOf(value) === index;
}

function GetTimeEvolved( datetime,now )
{
if(datetime=='0000-00-00 00:00:00' || datetime=='null' || datetime=='NULL')
{
    return "";
}
var datetime = typeof datetime !== 'undefined' ? datetime : "2014-01-01 01:02:03.123456";
var now = typeof now !== 'undefined' ? now : "2014-01-01 01:02:03.123456";


var datetime = new Date( datetime ).getTime();
var now = new Date(now).getTime();
var color;


if(isNaN(now)|| now=='0000-00-00 00:00:00' || now=='null' || now=='NULL'){
now = new Date().getTime();
}

//console.log( datetime + " " + now);

if (datetime < now) {
    var milisec_diff = now - datetime;
}else{
    var milisec_diff = datetime - now;
}

//   var days = Math.floor(milisec_diff / 1000 / 60 / (60 * 24));
// var hours =  Math.floor(milisec_diff / 1000 / 60 / (60));
var minutes =  Math.floor(milisec_diff / 1000 / 60);
if(minutes<=60){
color = "optionsqtyG";
}
if(minutes>60 && minutes<=90){
    color = "optionsqtyY";
    }
if(minutes>90){
    color = "optionsqtyR";
    }    
return color;

//return days + " Days "+ date_diff.getHours() + " Hours " + date_diff.getMinutes() + " Minutes " + date_diff.getSeconds() + " Seconds "+rt;
}

function CovertTimeHere(date){
if(date!=null){
return date.substr(11,5);
}else{
    return ""; 
}
}

//toggle();
            function toggle(){ 
            $('.toggle').click(function(e) {
                e.preventDefault();
            //alert("yes");
                var $this = $(this);
            
                if ($this.next().hasClass('show')) {
                    $this.next().removeClass('show');
                    $this.next().slideUp(350);
                    //alert("jhkj")
                } 
                else {
                    $this.parent().parent().find('li .inner').removeClass('show');
                    $this.parent().parent().find('li .inner').slideUp(350);
                    $this.next().toggleClass('show');
                    $this.next().slideToggle(350);
                    // alert("hj")
                }
            }); 
            }          
            $(function () {
            
                $("#searchTxt").keyup(function () {
            
                    var searchText = $(this).val().toLowerCase();
            
                    $('ul > li').each(function () {
            
                    var currentLiText = $(this).text().toLowerCase(),
                        showCurrentLi = currentLiText.indexOf(searchText) !== -1;
            
                    $(this).toggle(showCurrentLi);
            
                    });
                });
            
                });
                                                                
    
//-----------------------------------------------------------
//$("#myMenu").swipe({
//swipeStatus: function (event, phase, direction, distance, duration, fingers) {
//    // alert(direction);
//    //  if (phase=="move" && direction =="right") {
//    //      document.getElementById("menu-list").style.width = "300px";
//    //      $('.nav-side-menu').show();
//    //       return false;
//    //  }
//    if (phase == "move" && direction == "left") {
//    //  alert(phase);
//    //  alert(direction);
//    closeMenu('myMenu');
//    //   document.getElementById("menu-list").style.width = "0px";
//    //  // $('.nav-side-menu').hide();
//    //   $( ".nav-side-menu" ).fadeOut( "20000", function() {
//    // Animation complete.
//    //});
//    //  openMenu('myMenu');
//    // return false;
//    }
//}
//});

//jQuery(".myclickk").swipe({
//swipeStatus: function (event, phase, direction, distance, duration, fingers) {
//    if (phase == "move" && direction == "right") {
//    openMenu('myMenu');
//    //                          document.getElementById("menu-list").style.width = "300px";
//    //                             $( ".nav-side-menu" ).fadeIn( "20000", function() {
//    //     // Animation complete.
//    //   });
//    //                            return false;
//    }
//}
//});



//document.addEventListener("backbutton", onBackKeyDown, false);
//    function onBackKeyDown() {
//        if (employeeList.style.display == "block") {
//        logoutFunction();
//        } else {
//        employeeList.style.display = "block";
//        containScan.style.display = "none";
//        subheader.style.display = "block";
//        document.getElementById("icon").className = "icon ion-android-menu";
//        }
//        
//        } 

//    function backfunction() {
//if (document.getElementById("icon").className == "icon ion-android-arrow-back visible") {
//    employeeList.style.display="block";
//    containScan.style.display="none";
//    subheader.style.display = "block";
//    //alert("bbnm")
//    document.getElementById("icon").className = "icon ion-android-menu";
//    //z.style.display = "none";
//} else {
//    openMenu('myMenu');
//}
//
//}  

//function logoutFunction(){
//        if (confirm("Are you sure you want to Logout?")) {
//            window.location.href="../index.html";
//        }
//        }  



var myInfoDate = [];
function SubmitBtn(){
var datefrom = document.getElementById("from").value;
//var dateto = document.getElementById("to").value;
if(datefrom.trim() != ""){

var date = new Date(datefrom);
var month = date.getMonth() + 1;
var year = date.getFullYear();
if (month == 1){
if ( (year%100!=0) && (year%4==0) || (year%400==0)){
FebNumberOfDays = 29;
}else{
FebNumberOfDays = 28;
}
}
var FebNumberOfDays;
var dayPerMonth = ["31", ""+FebNumberOfDays+"","31","30","31","30","31","31","30","31","30","31"]

var numOfDays = dayPerMonth[month];
var from = year+"-"+month+"-1";
var to = year+"-"+month+"-"+dayPerMonth[month];
for (j=0;j<ALLEMPLOYEES.length;j++){
$("#employeelist"+j+"").empty();
var empDate = "";
for(var k=1; k<=numOfDays; k++){
if(k==10 || k==20 || k==30){
empDate += '<div class="circledate employeedate" id="'+ALLEMPLOYEES[j]['id']+"id"+k+'" style="display: inline-block; background-color:#FFE766">'+k+'</div>&nbsp<br>';
} else{
empDate += '<div class="circledate employeedate" id="'+ALLEMPLOYEES[j]['id']+"id"+k+'" style="display: inline-block;background-color:#FFE766">'+k+'</div>&nbsp';
}

//onclickdate(ALLEMPLOYEES[j]['id']+"id"+k,j);
// myInfoDate[k] = "00:00";

}
$("#employeelist"+j+"").append("<li><ul class='innerbox'><li><div id='datelist"+j+"'></div><br/><span style='width:1px;color:transparent;display:none;'>" +
ALLEMPLOYEES[j]['name'] + "</span><span></span>"+empDate+"</li></ul></li>");  

//onclickfunction(ALLEMPLOYEES[j]['id']+"id"+days,j,0);
}
//alert("http://192.168.1.2/liveratrack_web/login/master/getEmployeeAttendancedate?from="+datefrom+"&to="+dateto+"");
var days = getDateDifference(datefrom);
$.ajax({

//url:"http://192.168.1.2/liveratrack_web/login/master/getEmployeeAttendancedate?from="+from+"&to="+to+"",
url:""+serverUrl+"employee/getEmployeeAttendancedate?from="+from+"&to="+to+"",
type: "GET",
data: { 

},
dataType: "json",
success: function(returnedData) {
var CircleColor;
// alert(ALLEMPLOYEES);
//  $("#employeelist"+0+"".empty());
for (j=0;j<ALLEMPLOYEES.length;j++){
var counter = 0;
var CircleColor;
//    for(var k=1; k<=numOfDays; k++){ 
//alert(returnedData.length);
for(i=0;i<returnedData.length;i++){
// alert(ALLEMPLOYEES);

if(ALLEMPLOYEES[j]['id'] == returnedData[i]['employeeID']){

//  alert(returnedData[i]['employeeID'])
var days= getDay(returnedData[i]['datetime']);
var dateTime = returnedData[i]['datetime'];
counter++;
// alert(days);
CircleColor= "palegreen";
//alert(j);
//  alert("green") ;
document.getElementById(""+ALLEMPLOYEES[j]['id']+"id"+days+"").style.background = CircleColor;
//alert(returnedData[i]['datetime']);
// document.getElementById(""+ALLEMPLOYEES[j]['id']+"id"+days+"").onclick = function(){showTime(dateTime,j)}
onclickfunction(ALLEMPLOYEES[j]['id']+"id"+days,j,dateTime);
//document.getElementById("datelist"+j+"").style.background=GetTimeEvolved(date,"null");
//  myInfoDate[ALLEMPLOYEES[j]['id']+""+k] = '<div class='+GetTimeEvolved(returnedData[i]['datetime'],"null")+'>'+CovertTimeHere(returnedData[i]['datetime'])+'</div>'
}
}
//$("#employeelist"+j+"").append("<li><ul class='innerbox'><li>"+empDate+"</li></ul></li>");  

$("#attendanceNum"+j+"").html(counter+"/"+numOfDays);
} 

// $("#"+ALLEMPLOYEES[j]['id']+"id"+k+"").click(function(){
//   $(".employeedate").click(function(){
// //  alert("fghdjfjd");
//  });
}

});
$("#alertMsgTxt").text("");
}else{

$("#alertMsgTxt").text("Select Month!");
}
} 
function getDateDifference(daten) {
var date1 = new Date();
var date2 = new Date(daten);
if (daten != '0000-00-00' && daten != '') {
var timeDiff = (date2.getTime() - date1.getTime());
//alert(timeDiff);
var diffDays = Math.ceil(timeDiff / (1000 * 3600 * 24));
return diffDays;
} else {
return "N.A";
}
}
function getDay(daten){
var daten = daten.split(" ");
var date = new Date(daten[0]);
var day =   date.getDate();
return day;
}       
function onclickfunction(id,j,datetime){
//alert(datetime);
document.getElementById(id).onclick = function(){showTime(datetime,j)}
} 
function showTime(date,j){
// if(date != 0){
document.getElementById("datelist"+j+"").className = GetTimeEvolved(date,"null");
//document.getElementById("datelist"+j+"").style.background=GetTimeEvolved(date,"null");
document.getElementById("datelist"+j+"").innerHTML = CovertTimeHere(date);
// alert(date);
//  }else{
//   document.getElementById("datelist"+j+"").innerHTML = "00:00";
//  }
}
//-----------------------------------------------------------          

</script>
